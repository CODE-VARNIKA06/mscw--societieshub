import { useState, useEffect, useCallback } from 'react';
import { api } from '@/services/api';

const STORAGE_KEY = 'mscw_following_societies';
const USER_ID_KEY = 'mscw_user_id';

const getOrCreateUserId = (): string => {
  let userId = localStorage.getItem(USER_ID_KEY);
  if (!userId) {
    userId = 'user_' + Math.random().toString(36).substring(2, 15);
    localStorage.setItem(USER_ID_KEY, userId);
  }
  return userId;
};

export const useFollowing = () => {
  const [following, setFollowing] = useState<string[]>([]);
  const userId = getOrCreateUserId();

  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      try {
        setFollowing(JSON.parse(stored));
      } catch {
        setFollowing([]);
      }
    }
  }, []);

  const toggleFollow = useCallback((societyId: string) => {
    setFollowing(prev => {
      const isCurrentlyFollowing = prev.includes(societyId);
      const newFollowing = isCurrentlyFollowing
        ? prev.filter(id => id !== societyId)
        : [...prev, societyId];
      
      localStorage.setItem(STORAGE_KEY, JSON.stringify(newFollowing));
      
      if (!isCurrentlyFollowing) {
        api.followSociety(userId, societyId).catch(console.error);
      }
      
      return newFollowing;
    });
  }, [userId]);

  const isFollowing = useCallback((societyId: string) => {
    return following.includes(societyId);
  }, [following]);

  return {
    following,
    toggleFollow,
    isFollowing,
    followingCount: following.length
  };
};
