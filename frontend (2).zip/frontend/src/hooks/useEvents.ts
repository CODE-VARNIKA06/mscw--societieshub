import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { api, BackendEvent } from '@/services/api';

export const useEvents = () => {
  const queryClient = useQueryClient();

  const { data: events, isLoading, error } = useQuery({
    queryKey: ['events'],
    queryFn: api.getEvents,
    staleTime: 1000 * 60 * 5,
  });

  const addEventMutation = useMutation({
    mutationFn: ({ title, society, date }: { title: string; society: string; date: string }) =>
      api.addEvent(title, society, date),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['events'] });
    },
  });

  return {
    events: events || [],
    isLoading,
    error,
    addEvent: addEventMutation.mutate,
    isAddingEvent: addEventMutation.isPending,
  };
};
