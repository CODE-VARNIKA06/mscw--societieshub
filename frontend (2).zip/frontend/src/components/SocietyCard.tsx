import { motion } from 'framer-motion';
import { Heart, ExternalLink, Instagram, Linkedin, Mail, Users, Calendar } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Society, getCategoryColor, getStatusBadge, getStatusText, categoryLabels } from '@/data/societies';
import { useFollowing } from '@/hooks/useFollowing';
import { useState } from 'react';
import { RegistrationModal } from './RegistrationModal';

interface SocietyCardProps {
  society: Society;
  index: number;
  onClick: () => void;
}

export const SocietyCard = ({ society, index, onClick }: SocietyCardProps) => {
  const { isFollowing, toggleFollow } = useFollowing();
  const [isHearting, setIsHearting] = useState(false);
  const [showRegistration, setShowRegistration] = useState(false);
  const following = isFollowing(society.id);

  const handleFollow = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsHearting(true);
    toggleFollow(society.id);
    setTimeout(() => setIsHearting(false), 300);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ delay: index * 0.05, duration: 0.5 }}
      whileHover={{ y: -8, transition: { duration: 0.3 } }}
      className="group relative"
    >
      <div 
        className="glass-card overflow-hidden cursor-pointer card-hover"
        onClick={onClick}
        style={{
          boxShadow: `0 0 0 1px hsl(${society.colorAccent} / 0.1), 0 4px 30px rgba(0, 0, 0, 0.2)`
        }}
      >
        {/* Glow Effect on Hover */}
        <div 
          className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"
          style={{
            background: `radial-gradient(circle at 50% 0%, hsl(${society.colorAccent} / 0.15), transparent 70%)`
          }}
        />

        {/* Header with gradient */}
        <div 
          className="relative h-24 overflow-hidden"
          style={{
            background: `linear-gradient(135deg, hsl(${society.colorAccent} / 0.3) 0%, hsl(${society.colorAccent} / 0.1) 100%)`
          }}
        >
          <div className="absolute inset-0 bg-gradient-to-t from-card to-transparent" />
          
          {/* Follow Button */}
          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={handleFollow}
            className={`absolute top-3 right-3 w-10 h-10 rounded-full flex items-center justify-center transition-all ${
              following 
                ? 'bg-primary text-primary-foreground' 
                : 'bg-background/50 backdrop-blur-sm text-foreground hover:bg-background/70'
            }`}
          >
            <Heart 
              className={`w-5 h-5 ${isHearting ? 'heart-beat' : ''} ${following ? 'fill-current' : ''}`} 
            />
          </motion.button>

          {/* Society Initial */}
          <div 
            className="absolute bottom-0 left-4 translate-y-1/2 w-14 h-14 rounded-2xl flex items-center justify-center text-2xl font-display font-bold border-2 border-card"
            style={{
              background: `linear-gradient(135deg, hsl(${society.colorAccent}), hsl(${society.colorAccent} / 0.7))`,
              color: 'white'
            }}
          >
            {society.name.charAt(0)}
          </div>
        </div>

        {/* Content */}
        <div className="p-4 pt-10">
          <div className="flex items-start justify-between mb-3">
            <div>
              <h3 className="font-display font-bold text-lg text-foreground group-hover:text-primary transition-colors">
                {society.name}
              </h3>
              <p className="text-sm text-muted-foreground">{society.department}</p>
            </div>
          </div>

          {/* Badges */}
          <div className="flex flex-wrap gap-2 mb-3">
            <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${getCategoryColor(society.category)}`}>
              {categoryLabels[society.category]}
            </span>
            <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${getStatusBadge(society.registrationStatus)}`}>
              {getStatusText(society.registrationStatus)}
            </span>
          </div>

          {/* Description */}
          <p className="text-sm text-muted-foreground line-clamp-2 mb-4">
            {society.description}
          </p>

          {/* Stats */}
          <div className="flex items-center gap-4 text-sm text-muted-foreground mb-4">
            <div className="flex items-center gap-1.5">
              <Users className="w-4 h-4" />
              <span>{society.memberCount} members</span>
            </div>
            {society.fest && (
              <div className="flex items-center gap-1.5">
                <Calendar className="w-4 h-4" />
                <span>{society.fest.name}</span>
              </div>
            )}
          </div>

          {/* Footer Actions */}
          <div className="flex items-center justify-between pt-3 border-t border-border/50">
            <div className="flex items-center gap-2">
              {society.contact.instagram && (
                <a 
                  href={society.contact.instagram} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  onClick={(e) => e.stopPropagation()}
                  className="w-8 h-8 rounded-lg bg-secondary/50 flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-secondary transition-all"
                >
                  <Instagram className="w-4 h-4" />
                </a>
              )}
              {society.contact.linkedin && (
                <a 
                  href={society.contact.linkedin} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  onClick={(e) => e.stopPropagation()}
                  className="w-8 h-8 rounded-lg bg-secondary/50 flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-secondary transition-all"
                >
                  <Linkedin className="w-4 h-4" />
                </a>
              )}
              {society.contact.email && (
                <a 
                  href={`mailto:${society.contact.email}`}
                  onClick={(e) => e.stopPropagation()}
                  className="w-8 h-8 rounded-lg bg-secondary/50 flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-secondary transition-all"
                >
                  <Mail className="w-4 h-4" />
                </a>
              )}
            </div>

            {society.registrationStatus === 'open' && (
              <Button
                size="sm"
                className="bg-primary/10 text-primary hover:bg-primary hover:text-primary-foreground"
                onClick={(e) => {
                  e.stopPropagation();
                  setShowRegistration(true);
                }}
              >
                <ExternalLink className="w-3.5 h-3.5 mr-1.5" />
                Register
              </Button>
            )}
          </div>
        </div>
      </div>

      <RegistrationModal
        societyName={society.name}
        isOpen={showRegistration}
        onClose={() => setShowRegistration(false)}
      />
    </motion.div>
  );
};
