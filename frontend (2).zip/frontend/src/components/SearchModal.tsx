import { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, X, ArrowRight, Heart } from 'lucide-react';
import { societies, categoryLabels, getCategoryColor, getStatusBadge, getStatusText } from '@/data/societies';
import { useFollowing } from '@/hooks/useFollowing';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectSociety: (societyId: string) => void;
}

export const SearchModal = ({ isOpen, onClose, onSelectSociety }: SearchModalProps) => {
  const [query, setQuery] = useState('');
  const { isFollowing, toggleFollow } = useFollowing();

  useEffect(() => {
    if (isOpen) {
      setQuery('');
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'auto';
    }
    return () => {
      document.body.style.overflow = 'auto';
    };
  }, [isOpen]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'k' && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        if (!isOpen) {
          // This would need to be handled by parent
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  const results = useMemo(() => {
    if (!query.trim()) return societies.slice(0, 5);
    
    const lowerQuery = query.toLowerCase();
    return societies.filter(society =>
      society.name.toLowerCase().includes(lowerQuery) ||
      society.department.toLowerCase().includes(lowerQuery) ||
      society.description.toLowerCase().includes(lowerQuery) ||
      categoryLabels[society.category].toLowerCase().includes(lowerQuery)
    );
  }, [query]);

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-start justify-center pt-[10vh]">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-background/80 backdrop-blur-md"
            onClick={onClose}
          />

          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            transition={{ type: "spring", damping: 25, stiffness: 300 }}
            className="relative w-full max-w-2xl mx-4 glass-card rounded-2xl overflow-hidden shadow-2xl"
          >
            {/* Search Input */}
            <div className="relative border-b border-border/50">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <input
                type="text"
                placeholder="Search societies, departments, events..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                autoFocus
                className="w-full pl-12 pr-12 py-4 bg-transparent text-foreground placeholder:text-muted-foreground focus:outline-none text-lg"
              />
              <button
                onClick={onClose}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Results */}
            <div className="max-h-[60vh] overflow-y-auto p-2">
              {results.length > 0 ? (
                <div className="space-y-1">
                  {!query.trim() && (
                    <p className="px-3 py-2 text-xs text-muted-foreground uppercase tracking-wider">
                      Popular Societies
                    </p>
                  )}
                  {results.map((society, index) => (
                    <motion.button
                      key={society.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.03 }}
                      onClick={() => {
                        onSelectSociety(society.id);
                        onClose();
                      }}
                      className="w-full p-4 rounded-xl flex items-center gap-4 text-left hover:bg-secondary/50 transition-colors group"
                    >
                      {/* Society Initial */}
                      <div 
                        className="w-12 h-12 rounded-xl flex items-center justify-center text-lg font-display font-bold shrink-0"
                        style={{
                          background: `linear-gradient(135deg, hsl(${society.colorAccent}), hsl(${society.colorAccent} / 0.7))`,
                          color: 'white'
                        }}
                      >
                        {society.name.charAt(0)}
                      </div>

                      {/* Society Info */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <h4 className="font-semibold text-foreground truncate">
                            {society.name}
                          </h4>
                          <span className={`px-2 py-0.5 rounded-full text-xs ${getCategoryColor(society.category)}`}>
                            {categoryLabels[society.category]}
                          </span>
                        </div>
                        <p className="text-sm text-muted-foreground truncate">
                          {society.department}
                        </p>
                      </div>

                      {/* Status */}
                      <span className={`px-2.5 py-1 rounded-full text-xs font-medium shrink-0 ${getStatusBadge(society.registrationStatus)}`}>
                        {getStatusText(society.registrationStatus)}
                      </span>

                      {/* Arrow */}
                      <ArrowRight className="w-4 h-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity shrink-0" />
                    </motion.button>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <Search className="w-12 h-12 mx-auto mb-4 text-muted-foreground/50" />
                  <p className="text-muted-foreground">No societies found for "{query}"</p>
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="border-t border-border/50 px-4 py-3 flex items-center justify-between text-xs text-muted-foreground">
              <div className="flex items-center gap-4">
                <span className="flex items-center gap-1">
                  <kbd className="px-1.5 py-0.5 rounded bg-secondary text-[10px]">↵</kbd>
                  to select
                </span>
                <span className="flex items-center gap-1">
                  <kbd className="px-1.5 py-0.5 rounded bg-secondary text-[10px]">esc</kbd>
                  to close
                </span>
              </div>
              <span>{results.length} results</span>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
