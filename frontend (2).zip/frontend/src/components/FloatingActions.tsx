import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Calendar, ArrowUp, X } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface FloatingActionsProps {
  onNavigate: (section: string) => void;
}

export const FloatingActions = ({ onNavigate }: FloatingActionsProps) => {
  const [showScrollTop, setShowScrollTop] = useState(false);
  const [scrollProgress, setScrollProgress] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      const scrollY = window.scrollY;
      const docHeight = document.documentElement.scrollHeight - window.innerHeight;
      const progress = (scrollY / docHeight) * 100;
      
      setScrollProgress(progress);
      setShowScrollTop(scrollY > 500);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <>
      {/* Floating Calendar Button */}
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 1.5 }}
        className="fixed bottom-6 right-6 z-40"
      >
        <Button
          size="lg"
          className="w-14 h-14 rounded-full shadow-lg bg-gradient-to-br from-primary to-accent hover:opacity-90 glow-primary"
          onClick={() => onNavigate('calendar')}
        >
          <Calendar className="w-6 h-6" />
        </Button>
      </motion.div>

      {/* Scroll to Top with Progress */}
      <AnimatePresence>
        {showScrollTop && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="fixed bottom-6 left-6 z-40"
          >
            <div className="relative">
              {/* Progress Ring */}
              <svg className="w-14 h-14 -rotate-90">
                <circle
                  cx="28"
                  cy="28"
                  r="24"
                  stroke="currentColor"
                  strokeWidth="3"
                  fill="none"
                  className="text-muted/30"
                />
                <circle
                  cx="28"
                  cy="28"
                  r="24"
                  stroke="currentColor"
                  strokeWidth="3"
                  fill="none"
                  className="text-primary"
                  strokeDasharray={`${2 * Math.PI * 24}`}
                  strokeDashoffset={`${2 * Math.PI * 24 * (1 - scrollProgress / 100)}`}
                  strokeLinecap="round"
                />
              </svg>
              
              {/* Button */}
              <Button
                size="icon"
                variant="ghost"
                className="absolute inset-0 w-14 h-14 rounded-full hover:bg-primary/10"
                onClick={scrollToTop}
              >
                <ArrowUp className="w-5 h-5" />
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};
