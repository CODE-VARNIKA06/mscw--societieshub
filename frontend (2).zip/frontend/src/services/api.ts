export interface BackendSociety {
  id: string;
  name: string;
  description: string;
}

export interface BackendEvent {
  id: string;
  title: string;
  society: string;
  date: string;
}

export const api = {
  async getSocieties(): Promise<BackendSociety[]> {
    const response = await fetch('/api/societies');
    if (!response.ok) throw new Error('Failed to fetch societies');
    return response.json();
  },

  async addSociety(name: string, description: string): Promise<{ message: string }> {
    const response = await fetch('/api/add_society', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, description }),
    });
    if (!response.ok) throw new Error('Failed to add society');
    return response.json();
  },

  async getEvents(): Promise<BackendEvent[]> {
    const response = await fetch('/api/events');
    if (!response.ok) throw new Error('Failed to fetch events');
    return response.json();
  },

  async addEvent(title: string, society: string, date: string): Promise<{ message: string }> {
    const response = await fetch('/api/add_event', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title, society, date }),
    });
    if (!response.ok) throw new Error('Failed to add event');
    return response.json();
  },

  async followSociety(userId: string, society: string): Promise<{ message: string }> {
    const response = await fetch('/api/follow', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ user_id: userId, society }),
    });
    if (!response.ok) throw new Error('Failed to follow society');
    return response.json();
  },

  async register(email: string, password: string, role: string): Promise<{ message: string }> {
    const response = await fetch('/api/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password, role }),
    });
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Registration failed');
    }
    return response.json();
  },
};
