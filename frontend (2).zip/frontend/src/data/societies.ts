export type SocietyCategory = 'tech' | 'cultural' | 'sports' | 'arts' | 'media' | 'academic';
export type RegistrationStatus = 'open' | 'soon' | 'closed';

export interface Society {
  id: string;
  name: string;
  department: string;
  category: SocietyCategory;
  description: string;
  memberCount: number;
  registrationStatus: RegistrationStatus;
  registrationLink?: string;
  registrationDate?: string;
  fest?: {
    name: string;
    date: string;
    special?: string;
  };
  gallery: string[];
  contact: {
    instagram?: string;
    linkedin?: string;
    email?: string;
    president: string;
    prLead: string;
  };
  colorAccent: string;
  logo?: string;
}

export const societies: Society[] = [
  {
    id: "cybernauts",
    name: "Cybernauts",
    department: "Computer Science",
    category: "tech",
    description: "The premier tech society fostering innovation through hackathons, coding bootcamps, and industry connect sessions.",
    memberCount: 245,
    registrationStatus: "closed",
    fest: {
      name: "TechVista 2026",
      date: "March 2026",
      special: "Call for Sponsors"
    },
    gallery: [],
    contact: {
      instagram: "https://instagram.com/cybernauts",
      linkedin: "https://linkedin.com/company/cybernauts",
      email: "cybernauts@mscw.edu",
      president: "Aditya Sharma",
      prLead: "Priya Verma"
    },
    colorAccent: "217 91% 60%"
  },
  {
    id: "cultural-club",
    name: "Sanskriti",
    department: "Cultural Affairs",
    category: "cultural",
    description: "Celebrating diversity through dance, music, and theatrical performances that showcase our rich heritage.",
    memberCount: 320,
    registrationStatus: "open",
    registrationLink: "https://forms.mscw.edu/sanskriti",
    fest: {
      name: "Utsav 2026",
      date: "February 15, 2026"
    },
    gallery: [],
    contact: {
      instagram: "https://instagram.com/sanskriti_mscw",
      linkedin: "https://linkedin.com/company/sanskriti",
      email: "sanskriti@mscw.edu",
      president: "Ananya Reddy",
      prLead: "Rahul Singh"
    },
    colorAccent: "280 100% 70%"
  },
  {
    id: "sports-council",
    name: "Velocity",
    department: "Sports",
    category: "sports",
    description: "Empowering athletes through competitive sports, fitness programs, and inter-college championships.",
    memberCount: 180,
    registrationStatus: "soon",
    registrationDate: "January 20, 2026",
    fest: {
      name: "Sportathon 2026",
      date: "April 2026"
    },
    gallery: [],
    contact: {
      instagram: "https://instagram.com/velocity_mscw",
      email: "sports@mscw.edu",
      president: "Vikram Malhotra",
      prLead: "Neha Gupta"
    },
    colorAccent: "142 76% 50%"
  },
  {
    id: "art-society",
    name: "Canvas",
    department: "Fine Arts",
    category: "arts",
    description: "A creative haven for artists exploring painting, sculpture, digital art, and mixed media expressions.",
    memberCount: 95,
    registrationStatus: "open",
    registrationLink: "https://forms.mscw.edu/canvas",
    gallery: [],
    contact: {
      instagram: "https://instagram.com/canvas_mscw",
      email: "canvas@mscw.edu",
      president: "Meera Iyer",
      prLead: "Arjun Das"
    },
    colorAccent: "340 82% 65%"
  },
  {
    id: "media-club",
    name: "Lens & Quill",
    department: "Media Studies",
    category: "media",
    description: "Capturing stories through photography, videography, and journalism that matter to the campus community.",
    memberCount: 150,
    registrationStatus: "open",
    registrationLink: "https://forms.mscw.edu/lensquill",
    fest: {
      name: "Media Fest 2026",
      date: "March 2026"
    },
    gallery: [],
    contact: {
      instagram: "https://instagram.com/lensquill",
      linkedin: "https://linkedin.com/company/lensquill",
      email: "media@mscw.edu",
      president: "Kabir Khan",
      prLead: "Shreya Nair"
    },
    colorAccent: "38 95% 60%"
  },
  {
    id: "debate-society",
    name: "Eloquence",
    department: "Humanities",
    category: "academic",
    description: "Sharpening minds through debates, MUNs, and public speaking workshops that build future leaders.",
    memberCount: 110,
    registrationStatus: "closed",
    fest: {
      name: "Dialectica 2026",
      date: "February 2026"
    },
    gallery: [],
    contact: {
      instagram: "https://instagram.com/eloquence_mscw",
      email: "debate@mscw.edu",
      president: "Ishaan Mehta",
      prLead: "Riya Chopra"
    },
    colorAccent: "190 90% 50%"
  },
  {
    id: "robotics-club",
    name: "MechMinds",
    department: "Mechanical Engineering",
    category: "tech",
    description: "Building the future through robotics, automation, and cutting-edge mechanical innovations.",
    memberCount: 85,
    registrationStatus: "soon",
    registrationDate: "January 25, 2026",
    fest: {
      name: "RoboWars 2026",
      date: "April 2026"
    },
    gallery: [],
    contact: {
      instagram: "https://instagram.com/mechminds",
      email: "robotics@mscw.edu",
      president: "Siddharth Joshi",
      prLead: "Kavya Sharma"
    },
    colorAccent: "217 91% 60%"
  },
  {
    id: "music-society",
    name: "Euphony",
    department: "Music",
    category: "cultural",
    description: "Harmonizing voices and instruments to create melodies that resonate across the campus.",
    memberCount: 130,
    registrationStatus: "open",
    registrationLink: "https://forms.mscw.edu/euphony",
    gallery: [],
    contact: {
      instagram: "https://instagram.com/euphony_mscw",
      email: "music@mscw.edu",
      president: "Aakash Trivedi",
      prLead: "Divya Menon"
    },
    colorAccent: "280 100% 70%"
  }
];

export const getCategoryColor = (category: SocietyCategory): string => {
  const colors: Record<SocietyCategory, string> = {
    tech: 'badge-tech',
    cultural: 'badge-cultural',
    sports: 'badge-sports',
    arts: 'badge-arts',
    media: 'badge-media',
    academic: 'badge-academic'
  };
  return colors[category];
};

export const getStatusBadge = (status: RegistrationStatus): string => {
  const badges: Record<RegistrationStatus, string> = {
    open: 'status-open',
    soon: 'status-soon',
    closed: 'status-closed'
  };
  return badges[status];
};

export const getStatusText = (status: RegistrationStatus): string => {
  const texts: Record<RegistrationStatus, string> = {
    open: 'Open Now',
    soon: 'Opening Soon',
    closed: 'Closed'
  };
  return texts[status];
};

export const categoryLabels: Record<SocietyCategory, string> = {
  tech: 'Technology',
  cultural: 'Cultural',
  sports: 'Sports',
  arts: 'Arts & Design',
  media: 'Media',
  academic: 'Academic'
};
